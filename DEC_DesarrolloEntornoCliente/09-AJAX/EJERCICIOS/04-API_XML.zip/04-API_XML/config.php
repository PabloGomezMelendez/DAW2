<?php
// Datos de conexión a la base de datos
$db_host = "localhost";
$db_nombre = "soldadoj_general";
$db_usuario = "root";
$db_contraseña = "";
$db_charset = "utf8";
?>
